# The Answer Index, September 2026

> **RELEASE CANDIDATE — DO NOT PUBLISH OR UPLOAD WITHOUT BRANDON'S APPROVAL.**
> Zenodo has reserved the exact DOI for `v2026.09.2`, but the DOI will not be
> registered and the record will not be public until the Zenodo draft is
> published.

Open data for the Hendricks study of what AI answer engines cite.

## Release identity

| Field | Value |
|---|---|
| Package version | `v2026.09.2` |
| Release date | `2026-10-04` |
| Version DOI | [`10.5281/zenodo.23132107`](https://doi.org/10.5281/zenodo.23132107) — reserved; registration pending publication |
| Concept DOI | [`10.5281/zenodo.22242102`](https://doi.org/10.5281/zenodo.22242102) |
| Canonical study | [`https://hendricks.ai/research/the-answer-index`](https://hendricks.ai/research/the-answer-index) |
| Author | Brandon Lincoln Hendricks |
| ORCID | [`0009-0001-5728-0790`](https://orcid.org/0009-0001-5728-0790) |
| Publisher | Hendricks |
| License | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| Data captured | 2026-09-01 |
| Panel | Version 2.0, SHA `7a15060d8b5ec5f6` |

## What this is

The same fixed panel of 480 questions was sent to ChatGPT, Gemini, Perplexity,
and Google AI Overviews across eight industries. The run planned 1,920 probes:
1,919 returned a measurement and one Google AI Overview probe failed with a
vendor server error.

The raw capture contained 16,080 normalized domain-per-answer events across
7,776 domains. Eleven `google.com` events were Google AI Overview shopping or
redirect URLs rather than publisher sources. They were retained in
`excluded-cite-events.csv` for audit but excluded from source analysis. The
reported corpus therefore contains 16,069 analytic citation events across 7,775
distinct source domains.

The full question panel is published verbatim. That is deliberate. A study
whose instrument is private cannot be checked, and a finding that cannot be
checked is an assertion. Anyone can submit the same panel to comparable systems
and report where the results agree or diverge.

## Files

| File | What it holds |
|---|---|
| `README.md` | Release identity, package map, core definitions, and citation guidance. |
| `METHODOLOGY.md` | Study design, definitions, denominators, engine configuration, exclusions, and limitations. |
| `CHANGELOG.md` | Version history and a record of what changed. |
| `LICENSE` | CC BY 4.0 license notice. |
| `CITATION.cff` | Citation File Format metadata with the reserved version DOI and release date. |
| `CITATION.bib` | BibTeX citation metadata with the reserved version DOI and release date. |
| `SHA256SUMS.txt` | Per-file SHA-256 digests for every other file in this directory. |
| `panel-v2.0.json` | The complete 480-question instrument with industry and question-type labels. |
| `panel-v2.0.csv` | The same panel as a flat table. |
| `cite-events.csv` | One row per analytic `(question, engine, domain)` citation event after the documented plumbing exclusion. |
| `excluded-cite-events.csv` | The 11 retained `google.com` shopping or redirect events excluded as retrieval plumbing. |
| `citations-by-domain.csv` | Every analytic domain cited per engine, with numerator, denominator, presence share, and mass share. |
| `source-classification.csv` | Every analytic domain, its assigned class, assignment provenance, and cite-event count. |
| `engine-summary.csv` | Per-engine measured cells, citation eligibility, citation rate, events, distinct domains, and mean sources. |
| `industry-summary.csv` | Per-industry cells, citation events, distinct domains, and provider-owned share. |
| `question-type-summary.csv` | Citation rate and event count by question type and engine. |
| `chatgpt-by-question-shape.csv` | ChatGPT citation-bearing answers by question shape. |
| `cross-engine-agreement.csv` | Pairwise engine agreement under the stated comparison conditions. |
| `presence-vs-mass.csv` | Worked examples distinguishing answer presence from citation mass. |
| `blind-audit.csv` | The 60-domain blind sample used to audit source classification. |

## Definitions required to use the numbers

A citation event is counted once per measured answer and source domain, never
once per link. A domain linked three times inside one answer counts once. This
measures how often a source enters an answer without rewarding engines that emit
multiple links to the same domain.

A retrieval-plumbing event is a platform-owned redirect, search, cache, or
similar transport URL rather than the publisher source behind the result. The
release excludes five predeclared plumbing domains from source analysis:
`vertexaisearch.cloud.google.com`, `google.com`, `bing.com`,
`duckduckgo.com`, and `webcache.googleusercontent.com`. Only `google.com`
appeared in this run: 11 unique domain-per-answer events, all retained in
`excluded-cite-events.csv`.

Presence is the share of an engine's eligible answers containing a domain. Mass
is that domain's share of all analytic citation events the engine produced. They
are different measures. Reddit is present in 68.1 percent of Perplexity answers
and holds 4.45 percent of its citation events; quoting either alone misleads.

Google AI Overview source figures are computed against rendered panels only:
462 of 479 measured probes. A panel that never renders cannot cite a source.
No independent browser-screenshot control was run or preserved for this corpus,
so every AI Overview figure remains directional.

ChatGPT carried at least one citation in only 72 of its 480 answers, so any
ChatGPT share must state which denominator it uses.

## Known limitations

Read `METHODOLOGY.md` in full before citing. In short: this measures
answer-engine APIs, not consumer apps; source classification carries a measured
28 percent disagreement rate by domain and 32 percent when weighted to citation
mass; Gemini returns bare hostnames rather than page paths; stability was
measured for two engines on half the panel across a 38-minute gap; a citation is
not a click or recommendation; and eight industries do not represent every
industry.

The package contains the published instrument and analytic tables. It does not
contain the executable capture code or raw model-answer payloads. See the
reproduction section of `METHODOLOGY.md` for the exact boundary.

## How to cite

This release candidate is not yet citable as `v2026.09.2` because its reserved
Zenodo DOI is not registered until publication. After the record is published,
use:

> Hendricks, Brandon Lincoln. (2026). *The Answer Index: what AI answer engines
> cite across eight industries* (Version v2026.09.2) [Data set]. Hendricks.
> Zenodo. <https://doi.org/10.5281/zenodo.23132107>

Author identifier: <https://orcid.org/0009-0001-5728-0790>.

When quoting a figure, carry its denominator and distinguish 1,920 planned
probes from 1,919 measured probes. The 16,069 figure is the analytic cite-event
total after the 11 disclosed plumbing events are excluded.

## Corrections

`v2026.09.2` is a documentation and citation-metadata correction. It does not
change the question panel, captured observations, classifications, analytic
tables, or reported findings. The correction should be logged at
<https://hendricks.ai/corrections> when this version is published.

## License

This package is licensed under the Creative Commons Attribution 4.0
International license. It may be used, quoted, adapted, and redistributed with
attribution to Hendricks and Brandon Lincoln Hendricks.
