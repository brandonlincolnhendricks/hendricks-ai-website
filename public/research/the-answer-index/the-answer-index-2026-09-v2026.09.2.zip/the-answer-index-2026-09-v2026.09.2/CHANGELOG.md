# Changelog

## v2026.09.2 — 2026-10-04

**Release-candidate status:** not published. Zenodo has reserved exact version
DOI [`10.5281/zenodo.23132107`](https://doi.org/10.5281/zenodo.23132107);
registration remains pending publication.

Documentation and citation-metadata correction:

- Added package version, canonical study URL, concept DOI, author ORCID, and
  CC BY 4.0 metadata to the citation and release documents.
- Reserved an explicit release gate for the new Zenodo version DOI and release
  date; neither value will be invented before Zenodo provides it.
- Corrected “1,920 probes produced results” wording to distinguish 1,920 planned
  probes, 1,919 measured probes, and one vendor server failure.
- Disclosed that the raw capture contained 16,080 normalized domain-per-answer
  events across 7,776 domains and that 11 `google.com` Google AI Overview
  shopping or redirect events were excluded as retrieval plumbing.
- Clarified that no independent browser-screenshot control was run or preserved
  for this corpus and that every Google AI Overview figure remains directional.
- Added `excluded-cite-events.csv`, preserving those 11 excluded events for
  audit.
- Corrected package-internal file references and documented that executable
  capture code, taxonomy source rules, reviewer registry, and raw model-answer
  payloads are not included in the release package.
- Expanded the README file manifest to cover every shipped file.

No question, captured observation, source classification, analytic table,
reported finding, panel version, or panel hash changed. The analytic corpus
remains 16,069 cite events across 7,775 source domains from run
`run-2026-09-01T022903Z`.

## v2026.09.1 — 2026-09-01

First release. Panel v2.0, run `run-2026-09-01T022903Z`, 1,919 of 1,920
probes measured, 16,069 analytic citation events across 7,775 distinct source
domains. Stability round `run-2026-09-01T014944Z` covered the original 240
questions on Perplexity and Google AI Overviews only.
